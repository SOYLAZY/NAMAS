const projectsContainer = document.querySelector('.projects-container');

let isMouseDown = false;
let startX;
let scrollLeft;

projectsContainer.addEventListener('mousedown', (e) => {
    isMouseDown = true;
    startX = e.pageX - projectsContainer.offsetLeft;
    scrollLeft = projectsContainer.scrollLeft;
});

projectsContainer.addEventListener('mouseleave', () => {
    isMouseDown = false;
});

projectsContainer.addEventListener('mouseup', () => {
    isMouseDown = false;
});

projectsContainer.addEventListener('mousemove', (e) => {
    if (!isMouseDown) return;
    e.preventDefault();
    const x = e.pageX - projectsContainer.offsetLeft;
    const walk = (x - startX) * 3; // Ajusta la velocidad de desplazamiento
    projectsContainer.scrollLeft = scrollLeft - walk;
});
