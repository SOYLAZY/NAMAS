document.getElementById('theme-toggle').onclick = function() {
    document.body.classList.toggle('dark-theme');
};
